-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 06/11/2022 às 04:03
-- Versão do servidor: 10.4.22-MariaDB
-- Versão do PHP: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `pazeredo_desafio`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `adm_menu`
--

CREATE TABLE `adm_menu` (
  `id` int(11) NOT NULL,
  `adm_menu_id` int(11) DEFAULT NULL,
  `icone` varchar(50) DEFAULT NULL,
  `nome` varchar(50) NOT NULL,
  `link` mediumtext DEFAULT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `adm_menu`
--

INSERT INTO `adm_menu` (`id`, `adm_menu_id`, `icone`, `nome`, `link`, `status`) VALUES
(1, NULL, 'home', 'Dashboard', 'index.php', 1),
(2, NULL, 'tool', 'Administra&ccedil;&atilde;o', NULL, 1),
(3, 2, NULL, 'Usu&aacute;rios', 'usuariosList.php', 1),
(4, NULL, 'users', 'Clientes', 'clientesList.php', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `adm_menu_cliente`
--

CREATE TABLE `adm_menu_cliente` (
  `id` int(11) NOT NULL,
  `adm_menu_cliente_id` int(11) DEFAULT NULL,
  `icone` varchar(50) DEFAULT NULL,
  `nome` varchar(50) NOT NULL,
  `link` mediumtext DEFAULT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `adm_menu_cliente`
--

INSERT INTO `adm_menu_cliente` (`id`, `adm_menu_cliente_id`, `icone`, `nome`, `link`, `status`) VALUES
(25, NULL, 'home', 'Home', 'index.php', 1),
(26, NULL, 'user', 'Perfil', '', 1),
(27, 26, NULL, 'Editar Perfil', 'clientesCad.php', 1),
(36, NULL, 'power', 'Sair', 'loginSair.php', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `cad_clientes`
--

CREATE TABLE `cad_clientes` (
  `id` bigint(20) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `documento` varchar(14) DEFAULT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `celular` varchar(50) DEFAULT NULL,
  `telefone` varchar(50) DEFAULT NULL,
  `cep` varchar(9) DEFAULT NULL,
  `estado` char(2) DEFAULT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `bairro` varchar(255) DEFAULT NULL,
  `logradouro` varchar(255) DEFAULT NULL,
  `numero` varchar(50) DEFAULT NULL,
  `complemento` varchar(255) DEFAULT NULL,
  `senha` varchar(255) NOT NULL,
  `dt_create` datetime NOT NULL,
  `dt_update` datetime DEFAULT NULL,
  `dt_delete` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `cad_clientes`
--

INSERT INTO `cad_clientes` (`id`, `uid`, `nome`, `documento`, `tipo`, `email`, `celular`, `telefone`, `cep`, `estado`, `cidade`, `bairro`, `logradouro`, `numero`, `complemento`, `senha`, `dt_create`, `dt_update`, `dt_delete`, `status`) VALUES
(15, '1fb74a6970c419009543820852d9449e', 'Pedro Azeredo', '04695293005', NULL, 'pedro.azeredo@allscripts.com.br', '+55 (51) 99444-2101', '+55 (51) 3022-1050', '90130-061', 'RS', 'Porto Alegre', 'Menino Deus', 'Rua Gonçalves Dias', '999', 'apto 2203', 'e10adc3949ba59abbe56e057f20f883e', '2022-10-27 14:15:45', '2022-10-27 14:45:37', NULL, 1),
(16, 'e23f9840eb6c89a573029dd041647f08', 'Bruno Santos', '04695293005', NULL, 'bruno@gmail.com', '+51 (85) 884442-101', '+55 (85) 3623-0063', '90010-321', 'RS', 'Porto Alegre', 'Centro Histórico', 'Rua Coronel Fernando Machado', '999', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '2022-10-28 20:10:16', '2022-10-28 20:39:22', NULL, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `cad_usuarios`
--

CREATE TABLE `cad_usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `senha` mediumtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `uniqid` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `cad_usuarios`
--

INSERT INTO `cad_usuarios` (`id`, `nome`, `usuario`, `senha`, `email`, `uniqid`, `status`) VALUES
(1, 'admin', 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'pedro.azeredo93@gmail.com', '649eedd21c2fde9407c77880d1a1a54a', 1),
(2, 'Michel', 'michel', 'e10adc3949ba59abbe56e057f20f883e', 'michel.mileski@gmail.com', '2f9d1361288f7fc358da86741d66aa7a', 1),
(4, 'Bruno Santos', 'bruno-santos', 'e10adc3949ba59abbe56e057f20f883e', 'bruno@gmail.com', '2d0b3b6451640adc843cd7d1ed9b0afb', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `log_acessos_clientes`
--

CREATE TABLE `log_acessos_clientes` (
  `cad_clientes_id` bigint(20) NOT NULL,
  `data` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios_has_menu`
--

CREATE TABLE `usuarios_has_menu` (
  `cad_usuarios_id` int(11) NOT NULL,
  `adm_menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `usuarios_has_menu`
--

INSERT INTO `usuarios_has_menu` (`cad_usuarios_id`, `adm_menu_id`) VALUES
(2, 1),
(2, 2),
(2, 3),
(2, 5),
(2, 6),
(2, 21),
(2, 23),
(2, 26),
(2, 4),
(2, 7),
(2, 14),
(2, 15),
(2, 16),
(2, 25),
(2, 28),
(2, 17),
(2, 18),
(2, 19),
(2, 20),
(2, 22),
(3, 1),
(3, 2),
(3, 3),
(3, 5),
(3, 6),
(3, 21),
(3, 23),
(3, 26),
(3, 4),
(3, 7),
(3, 14),
(3, 15),
(3, 16),
(3, 25),
(3, 28),
(3, 17),
(3, 18),
(3, 19),
(3, 20),
(3, 22),
(4, 1),
(4, 2),
(4, 3),
(4, 4),
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 30),
(1, 33),
(1, 34),
(1, 35);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `adm_menu`
--
ALTER TABLE `adm_menu`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `adm_menu_cliente`
--
ALTER TABLE `adm_menu_cliente`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `cad_clientes`
--
ALTER TABLE `cad_clientes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `cad_usuarios`
--
ALTER TABLE `cad_usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `adm_menu`
--
ALTER TABLE `adm_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de tabela `adm_menu_cliente`
--
ALTER TABLE `adm_menu_cliente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de tabela `cad_clientes`
--
ALTER TABLE `cad_clientes`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `cad_usuarios`
--
ALTER TABLE `cad_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
